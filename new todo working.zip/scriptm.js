const blocknotesContainer = document.querySelector('[data-blocknotes]')
const newBlocknoteForm = document.querySelector('[data-new-blocknote-form]')
const newBlocknoteInput = document.querySelector('[data-new-blocknote-input]')
const blocknoteDisplayContainer = document.querySelector('[data-blocknote-display-container]')
const blocknoteTitleElement = document.querySelector('[data-blocknote-title]')

const listsContainer = document.querySelector('[data-lists]')
const newListForm = document.querySelector('[data-new-list-form]')
const newListInput = document.querySelector('[data-new-list-input]')
const deleteListButton = document.querySelector('[data-delete-list-button]')
const listDisplayContainer = document.querySelector('[data-list-display-container]')
const listTitleElement = document.querySelector('[data-list-title]')
const listCountElement = document.querySelector('[data-list-count]')

const tasksContainer = document.querySelector('[data-tasks]')
const taskTemplate = document.getElementById('task-template')
const newTaskForm = document.querySelector('[data-new-task-form]')
const newTaskInput = document.querySelector('[data-new-task-input]')
const clearCompleteTasksButton = document.querySelector('[data-clear-complete-tasks-button]')

const createBlocknoteButton = document.querySelector('.header .btn.bloocknote-crate')
const createListButton = document.querySelector('.header .btn.create');
const fontSizeSelector = document.getElementById('fontSizeSelector');
const fontSelector = document.getElementById('fontSelector');

const LOCAL_STORAGE_BLOCKNOTE_KEY = 'task.blocknotes'
const LOCAL_STORAGE_SELECTED_BLOCKNOTE_ID_KEY = 'task.selectedBlocknoteId'
const LOCAL_STORAGE_LIST_KEY = 'task.lists'
const LOCAL_STORAGE_SELECTED_LIST_ID_KEY = 'task.selectedListId'
let blocknotes = JSON.parse(localStorage.getItem(LOCAL_STORAGE_BLOCKNOTE_KEY)) || []
let selectedBlocknoteId = localStorage.getItem(LOCAL_STORAGE_SELECTED_BLOCKNOTE_ID_KEY)
let lists = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LIST_KEY)) || []
let selectedListId = localStorage.getItem(LOCAL_STORAGE_SELECTED_LIST_ID_KEY)

blocknotesContainer.addEventListener('click', e => {
  if (e.target.tagName.toLowerCase() === 'li') {
    selectedBlocknoteId = e.target.dataset.blocknoteId
    saveAndRender()
  }
})

listsContainer.addEventListener('click', e => {
  if (e.target.tagName.toLowerCase() === 'li') {
    selectedListId = e.target.dataset.listId
    console.log('Selected List ID after click:', selectedListId);
    saveAndRender()
  }
})

createListButton.addEventListener('click', function () {
  if (selectedBlocknoteId) {
    const selectedBlocknote = blocknotes.find(blocknote => blocknote.id === selectedBlocknoteId);
    if (selectedBlocknote) {
      // Переключаем видимость формы для нового списка
      newListForm.classList.toggle('visible');
    }
  }
});

tasksContainer.addEventListener('click', e => {
  if (e.target.tagName.toLowerCase() === 'input') {
    const selectedBlocknote = blocknotes.find(blocknote => blocknote.id === selectedBlocknoteId)
    const selectedList = selectedBlocknote.lists.find(list => list.id === selectedListId);
    // const selectedList = lists.find(list => list.id === selectedListId)
    const selectedTask = selectedList.tasks.find(task => task.id === e.target.id)
    selectedTask.complete = e.target.checked
    save()
    renderTaskCount(selectedList)
  }
})

fontSizeSelector.addEventListener('change', function () {
  const selectedFontSize = fontSizeSelector.value;
  document.body.style.fontSize = selectedFontSize + 'px';
});

fontSelector.addEventListener('change', function () {
  const selectedFont = fontSelector.value;
  document.body.style.fontFamily = selectedFont
});

clearCompleteTasksButton.addEventListener('click', e => {
    const selectedBlocknote = blocknotes.find(blocknote => blocknote.id === selectedBlocknoteId)
    const selectedList = selectedBlocknote.lists.find(list => list.id === selectedListId);
    selectedList.tasks = selectedList.tasks.filter(task => !task.complete)
    saveAndRender()
})

deleteListButton.addEventListener('click', e => {
    const selectedBlocknote = blocknotes.find(blocknote => blocknote.id === selectedBlocknoteId);
  if (selectedBlocknote) {
    // Update the selectedBlocknote.lists array
    selectedBlocknote.lists = selectedBlocknote.lists.filter(list => list.id !== selectedListId);
    saveAndRender();
  }
})

newBlocknoteForm.addEventListener('submit', e => {
  e.preventDefault()
  const date = new Date()
  const formattedDate = formatDate(date)
  const BlocknoteName = newBlocknoteInput.value + ' - ' + formattedDate
  if (BlocknoteName == null || BlocknoteName === '') return
  const blocknote = createBlocknote(BlocknoteName)
  newBlocknoteInput.value = null
  blocknotes.push(blocknote)
  saveAndRender()
  newBlocknoteForm.classList.remove('visible');
})

newListForm.addEventListener('submit', e => {
  e.preventDefault()
  const date = new Date()
  const formattedDate = formatDate(date)
  const listName = newListInput.value + ' - ' + formattedDate
  if (listName == null || listName === '') return
  const list = createList(listName)
  newListInput.value = null
  const selectedBlocknote = blocknotes.find(blocknote => blocknote.id === selectedBlocknoteId)
  selectedBlocknote.lists.push(list)
  saveAndRender()
  newListForm.classList.remove('visible');
})

newTaskForm.addEventListener('submit', e => {
  e.preventDefault();
  const taskName = newTaskInput.value.trim();
  if (taskName !== '') {
    const selectedBlocknote = blocknotes.find(blocknote => blocknote.id === selectedBlocknoteId)
    const selectedList = selectedBlocknote.lists.find(list => list.id === selectedListId);

    // Ensure selectedList is defined before accessing its tasks property
    if (selectedList) {
      const task = createTask(taskName);
      newTaskInput.value = '';
      selectedList.tasks.push(task);
      saveAndRender();
    } else {
      console.error('Selected list is undefined.');
    }
  }
});

listTitleElement.addEventListener('dblclick', function () {
  const selectedList = lists.find(list => list.id === selectedListId)
  const date = new Date()
  const formattedDate = formatDate(date)
  const currentTitle = listTitleElement.innerText;
  const newTitle = prompt('Enter a new title:', currentTitle);

  if (newTitle !== null) {
    selectedList.name = newTitle + ' - ' + formattedDate;
    saveAndRender();
  }
});

function createBlocknote(name) {
  return { id: Date.now().toString(), name: name, lists: [] }
}

function createList(name) {
  return { id: Date.now().toString(), name: name, tasks: [] }
}

function createTask(name) {
  return { id: Date.now().toString(), name: name, complete: false }
}

function saveAndRender() {
  save()
  render()
}

function save() {
  localStorage.setItem(LOCAL_STORAGE_BLOCKNOTE_KEY, JSON.stringify(blocknotes))
  localStorage.setItem(LOCAL_STORAGE_SELECTED_BLOCKNOTE_ID_KEY, selectedBlocknoteId)
  localStorage.setItem(LOCAL_STORAGE_LIST_KEY, JSON.stringify(lists))
  localStorage.setItem(LOCAL_STORAGE_SELECTED_LIST_ID_KEY, selectedListId)
}

function render() {
  // clearElement(listsContainer)
  clearElement(blocknotesContainer)
  // renderLists()
  renderBlocknotes()

  const selectedBlocknote = blocknotes.find(blocknote => blocknote.id === selectedBlocknoteId)
  if (selectedBlocknoteId == null) {
    blocknoteDisplayContainer.style.display = 'none'
  } else {
    blocknoteDisplayContainer.style.display = ''
    blocknoteTitleElement.innerText = selectedBlocknote.name
    renderLists(selectedBlocknote)
    console.log('Selected List ID:', selectedListId);
    const selectedList = selectedBlocknote.lists.find(list => list.id === selectedListId);
    console.log('Selected List:', selectedList);
  }

  const selectedList = selectedBlocknote.lists.find(list => list.id === selectedListId);
  if (selectedListId == null) {
    listDisplayContainer.style.display = 'none'
  } else {
    listDisplayContainer.style.display = ''
    listTitleElement.innerText = selectedList.name
    renderTaskCount(selectedList)
    clearElement(tasksContainer)
    renderTasks(selectedList)
  }
}

function renderTasks(selectedList) {
  const tasksContainer = document.querySelector('[data-tasks]');
  console.log('Rendering tasks for List ID:', selectedList.id);

  clearElement(tasksContainer);

  selectedList.tasks.forEach(task => {
    const taskElement = document.importNode(taskTemplate.content, true);
    const checkbox = taskElement.querySelector('input');
    checkbox.id = task.id;
    checkbox.checked = task.complete;
    const label = taskElement.querySelector('label');

    console.log('Task Name:', task.name); // Add this line

    label.htmlFor = task.id;
    label.append(task.name);
    tasksContainer.appendChild(taskElement);
  });

  console.log('Tasks rendered.');
}



function renderTaskCount(selectedList) {
  const incompleteTaskCount = selectedList.tasks.filter(task => !task.complete).length
  const taskString = incompleteTaskCount === 1 ? "task" : "tasks"
  listCountElement.innerText = `${incompleteTaskCount} ${taskString} remaining`
}

function renderBlocknotes() {
  blocknotes.forEach(blocknote => {
    const blocknoteElement = document.createElement('li');
    blocknoteElement.dataset.blocknoteId = blocknote.id;
    blocknoteElement.classList.add("blocknote-name");
    blocknoteElement.innerText = blocknote.name;
    if (blocknote.id === selectedBlocknoteId) {
      blocknoteElement.classList.add('active-blocknote');
    }
    blocknoteElement.addEventListener('click', () => {
      selectedBlocknoteId = blocknote.id;
      saveAndRender();
    });
    blocknotesContainer.appendChild(blocknoteElement);
  });
}

function renderLists(selectedBlocknote) {
  const listsContainer = document.querySelector('[data-lists]');
  clearElement(listsContainer);

  selectedBlocknote.lists.forEach(list => {
    const listElement = document.createElement('li');
    listElement.dataset.listId = list.id;
    listElement.classList.add("list-name");
    listElement.innerText = list.name;
    if (list.id === selectedListId) {
      listElement.classList.add('active-list');
    }
    listElement.addEventListener('click', () => {
      selectedListId = list.id;
      saveAndRender();
    });
    listsContainer.appendChild(listElement);
  });

  // Check if there's a selectedListId and it's in the current blocknote
  const selectedList = selectedBlocknote.lists.find(list => list.id === selectedListId);
  if (selectedList) {
    renderTasks(selectedList);
  } else {
    // If no selected list, clear tasks container
    clearElement(document.querySelector('[data-tasks]'));
  }
  console.log('Rendering lists...');
  console.log('Selected List ID:', selectedListId);
}


function clearElement(element) {
  while (element.firstChild) {
    element.removeChild(element.firstChild)
  }
}

function formatDate(date) {

  let dd = date.getDate();
  if (dd < 10) dd = '0' + dd;

  let mm = date.getMonth() + 1;
  if (mm < 10) mm = '0' + mm;

  let yy = date.getFullYear() % 100;
  if (yy < 10) yy = '0' + yy;

  date = dd + '.' + mm + '.' + yy;

  return date
}

render()