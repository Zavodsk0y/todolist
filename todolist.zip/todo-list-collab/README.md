# todo-list-collab

Files for the YouTube collab between Kevin and Kyle of Web Dev Simplified.
Kevin built out the HTML and styled it up, and then Kyle added the functionality with JS.

## The videos
- Kevin's video (HTML & CSS) - https://youtu.be/IhmSidOJSeE
- Web Dev Simplified's video (JS) - https://youtu.be/W7FaYfuwu70  
