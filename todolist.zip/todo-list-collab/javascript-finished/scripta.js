const listsContainer = document.querySelector('[data-lists]')
const newListForm = document.querySelector('[data-new-list-form]')
const newListInput = document.querySelector('[data-new-list-input]')
const deleteListButton = document.querySelector('[data-delete-list-button]')
const listDisplayContainer = document.querySelector('[data-list-display-container]')
const listTitleElement = document.querySelector('[data-list-title]')
const listCountElement = document.querySelector('[data-list-count]')
const tasksContainer = document.querySelector('[data-tasks]')
const taskTemplate = document.getElementById('task-template')
const newTaskForm = document.querySelector('[data-new-task-form]');
const newTaskInput = document.querySelector('[data-new-task-input]');
const clearCompleteTasksButton = document.querySelector('[data-clear-complete-tasks-button]');
const createListButton = document.querySelector('.header .btn.create');
const fontSizeSelector = document.getElementById('fontSizeSelector');
const fontSelector = document.getElementById('fontSelector');
const notebooksContainer = document.querySelector('[data-notebooks]')
const newNotebookForm = document.querySelector('[data-new-notebook-form]')
const newNotebookInput = document.querySelector('[data-new-notebook-input]')
const notebookTitleElement = document.querySelector('[data-notebook-title]')

const LOCAL_STORAGE_NOTEBOOK_KEY = 'task.notebooks'
const LOCAL_STORAGE_SELECTED_NOTEBOOK_ID_KEY = 'task.selectedNotebookId';
const LOCAL_STORAGE_LIST_KEY = 'task.lists'
const LOCAL_STORAGE_SELECTED_LIST_ID_KEY = 'task.selectedListId'
let notebooks = JSON.parse(localStorage.getItem(LOCAL_STORAGE_NOTEBOOK_KEY)) || []
let lists = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LIST_KEY)) || []
let selectedNotebookId = localStorage.getItem(LOCAL_STORAGE_SELECTED_NOTEBOOK_ID_KEY)
let selectedListId = localStorage.getItem(LOCAL_STORAGE_SELECTED_LIST_ID_KEY)

notebooksContainer.addEventListener('click', e => {
  if (e.target.tagName.toLowerCase() === 'li') {
    selectedNotebookId = e.target.dataset.notebookId
    saveAndRender()
  }
})

newNotebookForm.addEventListener('submit', e => {
  e.preventDefault()
  const notebookName = newNotebookInput.value
  if (notebookName == null || notebookName === '') return
  const notebook = createNotebook(notebookName)
  newNotebookInput.value = null
  notebooks.push(notebook)
  saveAndRender()
})

function createNotebook(name) {
  return { id: Date.now().toString(), name: name, lists: [] }
}

function renderNotebooks() {
  clearElement(notebooksContainer)
  notebooks.forEach(notebook => {
    const notebookElement = document.createElement('li')
    notebookElement.dataset.notebookId = notebook.id
    notebookElement.classList.add("notebook-name")
    notebookElement.innerText = notebook.name
    if (notebook.id === selectedNotebookId) {
      notebookElement.classList.add('active-notebook')
    }
    notebooksContainer.appendChild(notebookElement)
  })
}

listsContainer.addEventListener('click', e => {
  if (e.target.tagName.toLowerCase() === 'li') {
    selectedListId = e.target.dataset.listId
    saveAndRender()
  }
})

createListButton.addEventListener('click', function () {
  newListForm.classList.toggle('visible');
});

tasksContainer.addEventListener('click', e => {
  if (e.target.tagName.toLowerCase() === 'input') {
    const selectedList = lists.find(list => list.id === selectedListId)
    const selectedTask = selectedList.tasks.find(task => task.id === e.target.id)
    selectedTask.complete = e.target.checked
    save()
    renderTaskCount(selectedList)
  }
})

fontSizeSelector.addEventListener('change', function () {
  const selectedFontSize = fontSizeSelector.value;
  document.body.style.fontSize = selectedFontSize + 'px';
});

fontSelector.addEventListener('change', function () {
  const selectedFont = fontSelector.value;
  document.body.style.fontFamily = selectedFont
});

clearCompleteTasksButton.addEventListener('click', e => {
  const selectedList = lists.find(list => list.id === selectedListId)
  selectedList.tasks = selectedList.tasks.filter(task => !task.complete)
  saveAndRender()
})

deleteListButton.addEventListener('click', e => {
  lists = lists.filter(list => list.id !== selectedListId)
  selectedListId = null
  saveAndRender()
})

newListForm.addEventListener('submit', e => {
  e.preventDefault()
  const date = new Date()
  const formattedDate = formatDate(date)
  const listName = newListInput.value + ' - ' + formattedDate
  if (listName == null || listName === '') return
  const list = createList(listName)
  newListInput.value = null
  lists.push(list)
  saveAndRender()
  newListForm.classList.remove('visible');
})

newTaskForm.addEventListener('submit', e => {
  e.preventDefault()
  const taskName = newTaskInput.value
  if (taskName == null || taskName === '') return
  const task = createTask(taskName)
  newTaskInput.value = null
  const selectedList = lists.find(list => list.id === selectedListId)
  selectedList.tasks.push(task)
  saveAndRender()
})

listTitleElement.addEventListener('dblclick', function () {
  const selectedList = lists.find(list => list.id === selectedListId)
  const date = new Date()
  const formattedDate = formatDate(date)
  const currentTitle = listTitleElement.innerText;
  const newTitle = prompt('Enter a new title:', currentTitle);

  if (newTitle !== null) {
    selectedList.name = newTitle + ' - ' + formattedDate;
    saveAndRender();
  }
});

listTitleElement.addEventListener('dblclick', function () {
  const selectedList = lists.find(list => list.id === selectedListId)
  const date = new Date()
  const formattedDate = formatDate(date)
  const currentTitle = listTitleElement.innerText;
  const newTitle = prompt('Enter a new title:', currentTitle);

  if (newTitle !== null) {
    selectedList.name = newTitle + ' - ' + formattedDate;
    saveAndRender();
  }
});

tasksContainer.addEventListener('dblclick', function (e) {
  if (e.target.tagName.toLowerCase() === 'label') {
    const taskId = e.target.getAttribute('for');
    const selectedList = lists.find(list => list.id === selectedListId);
    const selectedTask = selectedList.tasks.find(task => task.id === taskId);

    const currentTaskName = selectedTask.name;
    const newTaskName = prompt('Enter a new task name:', currentTaskName);

    if (newTaskName !== null) {
      selectedTask.name = newTaskName;
      saveAndRender();
    }
  }
});

function createList(name) {
  return { id: Date.now().toString(), name: name, tasks: [] }
}

function createTask(name) {
  return { id: Date.now().toString(), name: name, complete: false }
}

function saveAndRender() {
  save()
  render()
}

function save() {
  localStorage.setItem(LOCAL_STORAGE_LIST_KEY, JSON.stringify(lists))
  localStorage.setItem(LOCAL_STORAGE_SELECTED_LIST_ID_KEY, selectedListId)

  localStorage.setItem(LOCAL_STORAGE_NOTEBOOK_KEY, JSON.stringify(notebooks))
  localStorage.setItem(LOCAL_STORAGE_SELECTED_NOTEBOOK_ID_KEY, selectedNotebookId)
}

function render() {
    clearElement(listsContainer);
    renderNotebooks();
  
    if (selectedNotebookId != null) {
      const selectedNotebook = notebooks.find((notebook) => notebook.id === selectedNotebookId);
      notebookDisplayContainer.style.display = '';
      notebookTitleElement.innerText = selectedNotebook.name;
      clearElement(listsContainer);
      renderLists(selectedNotebook);
    } else {
      notebookDisplayContainer.style.display = 'none';
    }
  
    if (selectedListId != null) {
      const selectedList = lists.find((list) => list.id === selectedListId);
      listDisplayContainer.style.display = '';
      listTitleElement.innerText = selectedList.name;
      renderTaskCount(selectedList);
      clearElement(tasksContainer);
      renderTasks(selectedList);
    } else {
      listDisplayContainer.style.display = 'none';
    }
  }
  

function renderTasks(selectedList) {
  selectedList.tasks.forEach(task => {
    const taskElement = document.importNode(taskTemplate.content, true)
    const checkbox = taskElement.querySelector('input')
    checkbox.id = task.id
    checkbox.checked = task.complete
    const label = taskElement.querySelector('label')
    label.htmlFor = task.id
    label.append(task.name)
    tasksContainer.appendChild(taskElement)
  })
}

function renderTaskCount(selectedList) {
  const incompleteTaskCount = selectedList.tasks.filter(task => !task.complete).length
  const taskString = incompleteTaskCount === 1 ? "task" : "tasks"
  listCountElement.innerText = `${incompleteTaskCount} ${taskString} remaining`
}

function renderLists() {
  selectedNotebook.lists.forEach(list => {
    const listElement = document.createElement('li')
    listElement.dataset.listId = list.id
    listElement.classList.add("list-name")
    listElement.innerText = list.name
    if (list.id === selectedListId) {
      listElement.classList.add('active-list')
    }
    listsContainer.appendChild(listElement)
  })
}

function load() {
    notebooks = JSON.parse(localStorage.getItem(LOCAL_STORAGE_NOTEBOOK_KEY)) || []
    selectedNotebookId = localStorage.getItem(LOCAL_STORAGE_SELECTED_NOTEBOOK_ID_KEY)
  // Load lists and selected list
  lists = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LIST_KEY)) || []
  selectedListId = localStorage.getItem(LOCAL_STORAGE_SELECTED_LIST_ID_KEY)

  
}

function clearElement(element) {
  while (element.firstChild) {
    element.removeChild(element.firstChild)
  }
}

function formatDate(date) {

  let dd = date.getDate();
  if (dd < 10) dd = '0' + dd;

  let mm = date.getMonth() + 1;
  if (mm < 10) mm = '0' + mm;

  let yy = date.getFullYear() % 100;
  if (yy < 10) yy = '0' + yy;

  date = dd + '.' + mm + '.' + yy;

  return date
}

render()